//
//  MyC4FW.h
//  MyC4FW
//
//  Created by Omar Juarez Ortiz on 2017-03-09.
//  Copyright © 2017 Omar Juarez Ortiz. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MyC4FW.
FOUNDATION_EXPORT double MyC4FWVersionNumber;

//! Project version string for MyC4FW.
FOUNDATION_EXPORT const unsigned char MyC4FWVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyC4FW/PublicHeader.h>



